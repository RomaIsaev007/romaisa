import random
from django.http import HttpResponseForbidden
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, get_user_model
from django.contrib.auth.forms import AuthenticationForm
from django.core.mail import send_mail
from django.contrib import messages
from rental_center import settings
from .models import Category, RentalItem
from .forms import CreateRentalForm, CustomUserCreationForm, CustomLoginForm, CategoryForm
from django.contrib.auth.decorators import login_required
from django.views.generic import ListView
from django.contrib.auth.decorators import user_passes_test
from django.core.paginator import Paginator



User = get_user_model()
from .forms import CustomUserCreationForm, CustomLoginForm
from django.contrib.auth.decorators import login_required

def registerView(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/login')
    else:
        form = CustomUserCreationForm()
    return render(request, 'registration/signup.html', {'form': form})

def loginView(request):
    if request.method == 'POST':
        form = CustomLoginForm(request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            request.session['just_logged_in'] = True
            return redirect('/home')
    else:
        form = CustomLoginForm()
    return render(request, 'registration/login.html', {'form': form})

@login_required
def homeView(request):
    just_logged_in = request.session.pop('just_logged_in', False)
    categories = Category.objects.all() 
    return render(request, 'home.html', {'just_logged_in': just_logged_in, 'categories': categories})

#88888888888888888888888888888888888888888888888888888888888888888888888888888

def generate_code():
    return ''.join([str(random.randint(0, 9)) for _ in range(6)])

def password_reset_request(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        try:
            user = User.objects.get(email=email)
            code = generate_code()
            request.session['reset_email'] = email
            request.session['reset_code'] = code

            send_mail(
                'Your Password Reset Code',
                f'Use this code to reset your password: {code}',
                settings.DEFAULT_FROM_EMAIL,
                [email],
                fail_silently=False,
            )
            messages.success(request, 'Reset code sent to your email.')
            return redirect('verify_code')
        except User.DoesNotExist:
            messages.error(request, 'No user with that email found.')
    return render(request, 'registration/auth/password_reset_request.html')


def verify_code_view(request):
    if request.method == 'POST':
        entered_code = request.POST.get('code')
        if entered_code == request.session.get('reset_code'):
            request.session['code_verified'] = True
            return redirect('set_new_password')
        else:
            messages.error(request, 'Invalid code.')
    return render(request, 'registration/auth/verify_code.html')


def set_new_password(request):
    if not request.session.get('code_verified'):
        return redirect('password_reset_request')

    if request.method == 'POST':
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')

        if password1 != password2:
            messages.error(request, 'Passwords do not match.')
        elif len(password1) < 8:
            messages.error(request, 'Password must be at least 8 characters.')
        else:
            email = request.session.get('reset_email')
            user = User.objects.get(email=email)
            user.set_password(password1)
            user.save()
            messages.success(request, 'Password reset successfully!')
            return redirect('login')

    return render(request, 'registration/auth/set_new_password.html')

@login_required
def add_category(request):
    if not request.user.is_staff:
        return redirect('home')

    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = CategoryForm()

    return render(request, 'home.html', {
        'form': form,
        'just_logged_in': False,
        'categories': Category.objects.all(),
        'show_add_category': True
    })


@login_required
def create_rental_item(request):
    if request.method == 'POST':
        form = CreateRentalForm(request.POST)
        if form.is_valid():
            rental_item = form.save(commit=False)
            rental_item.owner = request.user
            rental_item.status = False
            rental_item.save()
            return redirect('home')
    else:
        form = CreateRentalForm()
    
    categories = Category.objects.all() 
    return render(request, 'home.html', {
        'form': form,
        'show_create_rental': True,
        'categories': categories,
    })

class RentalItemListView(ListView):
    model = RentalItem
    template_name = 'rental_list.html'
    context_object_name = 'rental_items'

    def get_queryset(self):
        return RentalItem.objects.filter(status=False).exclude(id__isnull=True)


def approve_rental(request, item_id):
    item = get_object_or_404(RentalItem, id=item_id)
    item.status = True
    item.save()
    return redirect('rental-list')

def reject_rental(request, item_id):
    item = get_object_or_404(RentalItem, id=item_id)
    item.delete()
    return redirect('rental-list')

def all_rentals_view(request):
    rentals = RentalItem.objects.filter(status=1)

    if request.user.is_authenticated:
        rentals = rentals.exclude(owner=request.user)

    category_id = request.GET.get('category')
    if category_id:
        rentals = rentals.filter(category_id=category_id)

    sort_by = request.GET.get('sort', 'created_at')
    if sort_by in ['daily_price', '-daily_price', 'created_at', '-created_at']:
        rentals = rentals.order_by(sort_by)

    paginator = Paginator(rentals, 6)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'page_obj': page_obj,
        'categories': Category.objects.all(),
        'current_sort': sort_by,
        'current_category': category_id,
        'rentals': rentals  # rentals тізімін қосамыз
    }

    return render(request, 'home.html', context)