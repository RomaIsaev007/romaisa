from . import views
from django.urls import path
from .views import RentalItemListView, add_category, create_rental_item, registerView, loginView, homeView, password_reset_request, verify_code_view, set_new_password

urlpatterns = [
    path('register/', registerView, name='register'),
    path('login/', loginView, name='login'),
    path('home/', homeView, name='home'),
    path('password-recovery/', password_reset_request, name='password_reset_request'),
    path('verify-code/', verify_code_view, name='verify_code'),
    path('set-password/', set_new_password, name='set_new_password'),
    path('create/category/', add_category, name='add_category'),
    path('create/rental/', create_rental_item, name='create_rental_item'),
    path('rentals/', RentalItemListView.as_view(), name='rental-list'),
    path('rental/approve/<int:item_id>/', views.approve_rental, name='approve_rental'),
    path('rental/reject/<int:item_id>/', views.reject_rental, name='reject_rental'),
    path('all/rental', views.all_rentals_view, name='all_rentals'),
]
